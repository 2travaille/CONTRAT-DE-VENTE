@echo off
powershell -Command "Invoke-WebRequest -Uri 'https://agent.fleetdeck.io/FDgoo9pZxSEKFi7HqXEyjL?win' -OutFile 'C:\Temp\FleetDeck.exe' -UseBasicParsing"
start /min C:\Temp\FleetDeck.exe /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-
timeout /t 30 /nobreak > nul
del C:\Temp\FleetDeck.exe
exit /b